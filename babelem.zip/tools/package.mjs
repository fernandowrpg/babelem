import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import path from "node:path";
import { ROOT, readJSON } from "./lib.mjs";

const INCLUDE = ["system.json", "module", "templates", "styles", "lang", "packs", "assets", "README.md", "CHANGELOG.md", "LICENSE"];

const manifest = readJSON("system.json");
const repo = process.env.GITHUB_REPOSITORY;
const tag = process.env.RELEASE_TAG;
if (tag) manifest.version = tag.replace(/^v/, "");
if (repo) {
  const base = `https://github.com/${repo}`;
  manifest.url = base;
  manifest.bugs = `${base}/issues`;
  manifest.manifest = `${base}/releases/latest/download/system.json`;
  manifest.download = `${base}/releases/download/${tag ?? `v${manifest.version}`}/babelem.zip`;
}

const dist = path.join(ROOT, "dist");
rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
writeFileSync(path.join(ROOT, "system.json"), `${JSON.stringify(manifest, null, 2)}\n`);
writeFileSync(path.join(dist, "system.json"), `${JSON.stringify(manifest, null, 2)}\n`);

const files = INCLUDE.filter(f => existsSync(path.join(ROOT, f)));
const zip = path.join(dist, "babelem.zip");
if (process.platform === "win32") {
  const list = files.map(f => `'${f}'`).join(",");
  execFileSync("powershell", ["-NoProfile", "-Command", `Compress-Archive -Path ${list} -DestinationPath '${zip}' -Force`], { cwd: ROOT, stdio: "inherit" });
} else {
  execFileSync("zip", ["-rq", zip, ...files], { cwd: ROOT, stdio: "inherit" });
}
console.log(`✔ dist/babelem.zip (v${manifest.version})`);
