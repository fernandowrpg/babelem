---
name: Bug no sistema
about: Algo não funciona no Foundry
labels: bug
---

**Versão do Foundry (13 ou 14, build):**

**Versão do sistema Babelém:**

**O que aconteceu:**

**Passos para reproduzir:**

**Erro no console (F12), se houver:**
