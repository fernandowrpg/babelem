---
name: Ajuste de regra ou texto
about: Proponha uma mudança em regra, habilidade, ameaça ou tradução
labels: regras
---

**O que mudar** (nome da essência/traço/técnica/feitiço/ameaça ou página de regra):

**Arquivo em `src/packs/`:**

**Texto atual:**

**Texto proposto (pt):**

**Texto proposto (en), se souber:**

**Motivo / playtest:**
